=== Widget COFAR ===
Tags: Custom-filter-COFAR-Widget
Requires at least: 3.7
License: GPU

Widget personalizado de filtro de productos para la barra lateral de COFAR.

== Description ==
Widget personalizado para la barra lateral de COFAR, con este widget se pueden buscar productos por acción terapéutica y molécula, configurado para obtener todas las categorias hijo de Acción terapéutica (term-id: 1186) y todas las etiquetas que representan a las moléculas.